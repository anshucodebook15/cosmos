import { createBrowserRouter } from "react-router-dom";
import App from "../App";
import Test from "../pages/Test/Test";

export const SiteMap = [
  {
    name: "Home",
    path: "",
    element: "",
    children: [
      {
        name: "Home",
        path: "",
        element: <App />,
        children: [],
      },
      {
        name: "Home",
        path: "/test",
        element: <Test />,
        children: [],
      },
    ],
  },
  // {
  //   name: "About",
  //   path: "/about",
  //   element: "",
  //   children: [
  //     {
  //       name: "About",
  //       path: "",
  //       element: <About />,
  //       children: [],
  //     },
  //     {
  //       name: "Chairman’s Vision",
  //       path: "chairman",
  //       element: <Chairman />,
  //       children: [],
  //     },
  //     {
  //       name: "President & CEO Message",
  //       path: "presidentCEO",
  //       element: <PresidentCEO />,
  //       children: [],
  //     },
  //     {
  //       name: "Why Us?",
  //       path: "why-us",
  //       element: <WhyUs />,
  //       children: [],
  //     },
  //     {
  //       name: "Our Achievements",
  //       path: "achievements",
  //       element: <Achievements />,
  //       children: [],
  //     },
  //     {
  //       name: "Infrastructure",
  //       path: "infrastructure",
  //       element: <Infrastructure />,
  //       children: [],
  //     },
  //     {
  //       name: "Admissions & Branches",
  //       path: "admissions",
  //       element: <Admissions />,
  //       children: [],
  //     },
  //   ],
  // },
  // {
  //   name: "Academics",
  //   path: "/academics",
  //   element: <Academics />,
  //   children: [],
  // },
  // {
  //   name: "Blogs",
  //   path: "/blogs",
  //   element: "",
  //   children: [
  //     {
  //       // index: true,
  //       name: "Blogs",
  //       path: "",
  //       element: <Blogs />,
  //       children: [],
  //     },
  //     {
  //       name: "Blogs",
  //       path: ":id",
  //       element: <SingleBlog />,
  //       children: [],
  //     },
  //   ],
  // },
  // {
  //   name: "Photo Gallery",
  //   path: "/photo-gallery",
  //   element: <PhotoGallery />,
  //   children: [],
  // },
  // {
  //   name: "Video Gallery",
  //   path: "/video-gallery",
  //   element: <VideoGallery />,
  //   children: [],
  // },
  // {
  //   name: "Mandatory Public Disclouser",
  //   path: "/mdp",
  //   element: <Mdp />,
  //   children: [],
  // },
  // {
  //   name: "TC",
  //   path: "/tc",
  //   element: <TC />,
  //   children: [],
  // },
  // {
  //   name: "Result",
  //   path: "/result",
  //   element: <Results />,
  //   children: [],
  // },
  // {
  //   name: "E-Calender",
  //   path: "/e-calender",
  //   element: <ECalender />,
  //   children: [],
  // },
  // {
  //   name: "Little Champs",
  //   path: "/little-champs",
  //   element: <LittleChamps />,
  //   children: [],
  // },
  // {
  //   name: "Test",
  //   path: "/test",
  //   element: <Test />,
  //   children: [],
  // },
  // {
  //   name: "aasthatest",
  //   path: "/aasthatest",
  //   element: <AasthaTest />,
  //   children: [],
  // },
];

export const AppRoutes = createBrowserRouter(SiteMap);
