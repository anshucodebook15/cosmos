
import React from 'react'
import './Checkout.scss'

const Checkout = () => {
  return (
    <div className='Checkout'>
    <h2>Checkout </h2>
    </div>
  )
}

export default Checkout