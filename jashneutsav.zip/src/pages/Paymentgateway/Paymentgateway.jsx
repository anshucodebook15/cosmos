
import React from 'react'
import './Paymentgateway.scss'

const Paymentgateway = () => {
  return (
    <div className='Paymentgateway'>
    <h2>Paymentgateway </h2>
    </div>
  )
}

export default Paymentgateway