import React from "react";
import "./Booking.scss";

const Booking = () => {
  return (
    <div className="Booking">
      <h2>Booking </h2>
    </div>
  );
};

export default Booking;
