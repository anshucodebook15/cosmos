import React, { useState } from "react";
import "./Landing.scss";
import { SelectLanding } from "./LandingSlice";
import { useSelector } from "react-redux";
import Container from "@mui/material/Container";
import Navbar from "../../components/Navbar/Navbar";
import Grid from "@mui/material/Grid2";
import { Box } from "@mui/material";

const WhiteBox = ({ children }) => {
  return (
    <>
      <Box
        sx={{
          background: {
            lg: "red",
            md: "pink",
            sm: "blue",
            xs: "green",
          },
          color: "var(--gs-400)",
          padding: {
            lg: 5,
            md: 6,
            sm: 10,
          },
        }}
      >
        {children}
      </Box>
    </>
  );
};

const Landing = () => {
  const LandingData = useSelector(SelectLanding);

  console.log(LandingData);

  return (
    <div className="Landing">
      <Container maxWidth="lg">
        <h2>hello Asstha</h2>

<div className="whey">

</div>
        <WhiteBox>
          <Grid container>
            <Grid size={{ lg: 8, md: 4, sm: 6 }}>
              <h2>hello 8</h2>
            </Grid>
            <Grid size={4}>
              <h2>4</h2>
            </Grid>
          </Grid>
        </WhiteBox>

        <WhiteBox>
          <h2>hwool</h2>
        </WhiteBox>
      </Container>

      {/*  */}
    </div>
  );
};

export default Landing;
