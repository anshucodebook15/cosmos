import React from "react";
import "./Navbar.scss";
import Container from "@mui/material/Container";
import Grid from "@mui/material/Grid2";
import { Box } from "@mui/material";

const Navbar = () => {
  return (
    <div className="Navbar">
      <Container maxWidth="lg">
        <Box sx={{ padding: 2 }}>
          <Grid container>
            <Grid size={6}>
              <h2>logo</h2>
            </Grid>
            <Grid size={6}>
              <div className="floatright">
                <h2>chip</h2>
              </div>
            </Grid>
          </Grid>
        </Box>
      </Container>
    </div>
  );
};

export default Navbar;
