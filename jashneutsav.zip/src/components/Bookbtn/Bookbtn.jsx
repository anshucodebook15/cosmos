
import React from 'react'
import './Bookbtn.scss'

const Bookbtn = () => {
  return (
    <div className='Bookbtn'>
    <h2>Bookbtn </h2>
    </div>
  )
}

export default Bookbtn