
import React from 'react'
import './Footer.scss'

const Footer = () => {
  return (
    <div className='Footer'>
    <h2>Footer </h2>
    </div>
  )
}

export default Footer